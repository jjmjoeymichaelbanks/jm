_quick
  .addEventListener(
    'touchstart', (evt) =>
    {
      Generate(8);
    },
    {
      passive: true
    }
);
